﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zindex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> numbers = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                numbers.Add(double.Parse(s));
            }
            double mean = numbers.Average();
            double squared = numbers.Sum(d => Math.Pow(d - mean, 2));
            double stdeivation = Math.Sqrt(squared / numbers.Count());
            var zindex = numbers.ConvertAll(d => (d - mean) / stdeivation);
            int i = 0;
            foreach(double x in zindex)
            {
                MessageBox.Show(numbers[i] + " " + x);
                i = i + 1;
            }
        }
    }
}
